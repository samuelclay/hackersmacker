// injecter.js
self.port.on("init", function( scriptURLs ) {
    for (var url in scriptURLs) {
        var script = document.createElement( "script" );
        script.type = "text/javascript";
        script.src = scriptURLs[url];
        window.document.body.appendChild( script );
    }
});